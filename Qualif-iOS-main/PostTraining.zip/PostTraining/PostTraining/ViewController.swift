//
//  ViewController.swift
//  PostTraining
//
//  Created by prk on 19/04/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

